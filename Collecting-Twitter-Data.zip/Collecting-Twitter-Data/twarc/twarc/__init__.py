__version__ = '1.7.5'  # also in setup.py

from .client import Twarc
from .command import main
