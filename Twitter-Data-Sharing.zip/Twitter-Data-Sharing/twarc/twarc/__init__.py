__version__ = '1.8.1'  # also in setup.py

from .client import Twarc
from .command import main
